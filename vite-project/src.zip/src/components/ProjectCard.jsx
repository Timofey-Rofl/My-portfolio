import React from 'react';

const ProjectCard = ({ project }) => {
  return (
    <a href={project.url} target="_blank" rel="noopener noreferrer" className="square-card card-glass project-card">
      <img src={project.image} alt={project.title} className="project-icon" />
      
      <div className="project-info">
        <h3>{project.title}</h3>
        <p>{project.description}</p>
      </div>
    </a>
  );
};

export default ProjectCard;