import React from 'react';

const AvatarSwitcher = ({ avatars, index }) => {
  if (!avatars || avatars.length === 0) return null;
  
  return (
    <div className="avatar-container">
      <img 
        src={avatars[index].src} 
        alt="Avatar" 
        className="avatar-image"
      />
    </div>
  );
};

export default AvatarSwitcher;