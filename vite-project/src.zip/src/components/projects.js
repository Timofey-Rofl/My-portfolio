import gjIcon from '../assets/icons/GameJolt_logo.png'; // ← проверь имя!
import TSIcon from '../assets/icons/Tstore.png'

const PROJECTS = [
  {
    id: 1,
    title: 'GAMEJOLT',
    platform: 'GameJolt',
    description: 'Мои игры которые я создал сам и даже в них поиграть',
    url: 'https://gamejolt.com',
    image: gjIcon,
  },
  {
    id: 2,
    title: 'Bass suit for Lethal company',
    platform: 'Thunderstore',
    description: 'Мод добавляющий костюм Bass из Mega man classic в Lethal company',
    url: 'https://old.thunderstore.io/c/lethal-company/p/JALCoS_DevTeam/Mega_man_and_Bass/',
    image: TSIcon,
  },
  {
    id: 3,
    title: 'Khan suit for Lethal company',
    platform: 'Thunderstore',
    description: 'Мод добавляющий костюм Khan Doorman из Murder drones в Lethal company',
    url: 'https://old.thunderstore.io/c/lethal-company/p/JALCoS_DevTeam/KhanDoormansuit/',
    image: TSIcon,
  },
  {
    id: 4,
    title: 'Thad suit for Lethal company',
    platform: 'Thunderstore',
    description: 'Мод добавляющий костюм Thad из Murder drones в Lethal company',
    url: 'https://old.thunderstore.io/c/lethal-company/p/JALCoS_DevTeam/Thad/',
    image: TSIcon,
  },

  


];
export default PROJECTS;