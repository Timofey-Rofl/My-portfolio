import React, { useEffect } from 'react';

const Lightbox = ({ arts, index, onClose, onChange }) => {
  const currentArt = arts[index];

  // Навигация стрелками на клавиатуре
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') onChange((index + 1) % arts.length);
      if (e.key === 'ArrowLeft') onChange((index - 1 + arts.length) % arts.length);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [index, arts, onClose, onChange]);

  return (
    <div className="lightbox-overlay" onClick={onClose}>
      <div className="lightbox-content" onClick={(e) => e.stopPropagation()}>
        <button className="lightbox-close" onClick={onClose}>×</button>
        <button 
          className="lightbox-nav prev" 
          onClick={() => onChange((index - 1 + arts.length) % arts.length)}
        >
          ‹
        </button>
        
        <img src={currentArt.src} alt={currentArt.title} className="lightbox-image" />
        
        <button 
          className="lightbox-nav next" 
          onClick={() => onChange((index + 1) % arts.length)}
        >
          ›
        </button>
      </div>
    </div>
  );
};

export default Lightbox;