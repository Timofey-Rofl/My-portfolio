import React, { useState } from 'react';

const LinkCard = ({ link }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Прямая ссылка (where)
  if (link.type === 'where') {
    return (
      <a
        href={link.url}
        target="_blank"
        rel="noopener noreferrer"
        className="square-card card-glass link-card"
      >
        <img src={link.icon} alt={link.name} className="link-icon" />
        <h3>{link.name}</h3>
      </a>
    );
  }

  // Раскрывающаяся карточка (here)
  if (link.type === 'here') {
    return (
      <div
        className={`square-card card-glass link-card ${isExpanded ? 'expanded' : ''}`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <img src={link.icon} alt={link.name} className="link-icon" />
        <h3>{link.name}</h3>
        
        <div className="link-expandable-content">
          <p style={{ whiteSpace: 'pre-line' }}>{link.expandedText}</p>
        </div>
      </div>
    );
  }

  return null;
};

export default LinkCard;