const Gallery = ({ arts, onHover, onOpen }) => {
  return (
    <div className="gallery-container">
      {arts.map((art, index) => (
        <div 
          key={art.id} 
          className="gallery-item"
          onMouseEnter={() => onHover(art)}
          onMouseLeave={() => onHover(null)}
          onClick={() => onOpen(index)}
        >
          <img src={art.src} alt={art.title} />
        </div>
      ))}
    </div>
  );
};

export default Gallery;