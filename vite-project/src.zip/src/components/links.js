import discordIcon from '../assets/icons/Discord_logo.svg';
import youtubeIcon from '../assets/icons/Youtube_logo.svg';

const LINKS = [
  {
    id: 'discord',
    name: 'Мой Discord',
    type: 'here', // Раскрывающаяся карточка
    icon: discordIcon,
    expandedText: 'Мой ник: @t1moha_r0fl\nПишите, я всегда рад поболтать :3', // Текст, который покажется при клике
  },
  {
    id: 'youtube',
    name: 'Мой YouTube канал, ну типо архив а вроде нет',
    type: 'where', // Обычная ссылка
    icon: youtubeIcon,
    url: 'https://youtube.com',
  },
];
export default LINKS;