import React, { useState, useEffect } from 'react';
import changer from './components/changer';
import AvatarSwitcher from './components/AvatarSwitcher';
import LinkCard from './components/LinkCard';
import ProjectCard from './components/ProjectCard';
import Gallery from './components/Gallery';
import Lightbox from './components/Lightbox';
import arts from './components/arts';
import LINKS from './components/links';
import PROJECTS from './components/projects';
import './App.css';
import './index.css';

function App() {
  const [avatarIndex, setAvatarIndex] = useState(0);
  const [hoveredArt, setHoveredArt] = useState(null);
  const [lightboxIndex, setLightboxIndex] = useState(null);

  // Смена аватарки каждые 10 секунд
  useEffect(() => {
    if (changer.length <= 1) return;
    const id = setInterval(() => {
      setAvatarIndex((prev) => (prev + 1) % changer.length);
    }, 10000);
    return () => clearInterval(id);
  }, []);

  const currentAuthor = changer[avatarIndex]?.author ?? '';

  return (
    <div className="app-wrapper">
      {/* Фоновые слои */}
      <div className="bg-layer bg-layer--base" />
      <div
  className={`bg-layer bg-layer--hover${hoveredArt ? ' is-active' : ''}`}
  // Обрати внимание на кавычки внутри url("...") 👇
  style={hoveredArt ? { backgroundImage: `url("${hoveredArt.src}")` } : undefined}
/>
      {/* Новый слой затемнения (вместо body::before) */}
      <div className="bg-overlay" />

      <header>
        <nav>
          <a href="https://xn--l1aij1c.xn--p1ai/">Мряу.рф</a>
        </nav>
      </header>

      <main className="main-content">
  <div className="top-row">
    {/* Обо мне */}
    <div className="section-block about-section">
      <h1 className="section-title">Обо мне</h1>
      <div className="korobka">
        <AvatarSwitcher avatars={changer} id="avatar" index={avatarIndex} />
        <div id="content">
          <h1>T1moha_R0fls</h1>
          <p>или Signas/Shigunasu в этих ваших интернетах и для некоторых своих в доску.</p>
          <p>Я начинающий программист :3</p>
          <p>Быстро адаптируюсь и стараюсь учиться новому.</p>
          <p className="small-text">P.S. Наведись на проекты чтобы увидеть инфу</p>
        </div>
      </div>
    </div>

    {/* Где я есть */}
    <div className="section-block links-section">
      <h1 className="section-title">Где я есть</h1>
      <div className="links-grid">
        {LINKS.map((link) => <LinkCard key={link.id} link={link} />)}
      </div>
    </div>
  </div>

  {/* Проекты */}
  <div className="section-block projects-section">
    <h1 className="section-title">Проекты</h1>
    <div className="projects-grid">
      {PROJECTS.map((project) => <ProjectCard key={project.id} project={project} />)}
    </div>
  </div>

  {/* Творчество */}
  <div className="section-block arts-section">
    <h1 className="section-title">Творчество - или то как я умею рисовать</h1>
    <Gallery
      arts={arts}
      onHover={setHoveredArt}
      onOpen={(i) => setLightboxIndex(i)}
    />
  </div>
</main>

      <footer>
        <p>Сайт создан на коленках TOPы и Кощьки :3c</p>
        <p>Автор арта на аватарке: {currentAuthor}</p>
      </footer>

      {lightboxIndex !== null && (
        <Lightbox
          arts={arts}
          index={lightboxIndex}
          onClose={() => setLightboxIndex(null)}
          onChange={setLightboxIndex}
        />
      )}
    </div>
  );
}

export default App;